# PhoneCare Pro v2.0.0 APK Build & Test Guide

## 1. Prerequisites
- Android Studio Ladybug / Koala / Iguana (2024+)
- JDK 17
- Android SDK 35

## 2. Compile APK
Linux / macOS:
./gradlew assembleDebug

Windows:
gradlew.bat assembleDebug

Output APK:
app/build/outputs/apk/debug/app-debug.apk

## 3. Features Included:
- Smart Scan engine with multi-stage progress
- Room Database for local offline maintenance history
- Advanced Photo Cleaner (duplicates, burst shots, blurry, screenshots)
- Video Cleaner with duration, resolution & duplicate videos
- Battery Monitor with voltage, temp & charging advice
- Performance Assistant with RAM pressure & background app stats
- Security Centre with Google Play Protect checklist
- Google Play Billing v7 subscription integration prep