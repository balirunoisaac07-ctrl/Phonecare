package com.phonecare.pro

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.android.gms.ads.MobileAds
import com.phonecare.pro.data.db.AppDatabase
import com.phonecare.pro.data.db.MaintenanceHistoryEntity
import com.phonecare.pro.data.repository.StorageRepository
import com.phonecare.pro.data.repository.DeviceHealthRepository
import com.phonecare.pro.ui.screens.*
import com.phonecare.pro.ui.theme.PhoneCareProTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var storageRepo: StorageRepository
    private lateinit var healthRepo: DeviceHealthRepository
    private lateinit var database: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        database = AppDatabase.getDatabase(this)
        storageRepo = StorageRepository(this)
        healthRepo = DeviceHealthRepository(this)

        try {
            MobileAds.initialize(this) {}
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val permissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { results ->
            val allGranted = results.values.all { it }
            if (!allGranted) {
                Toast.makeText(this, "Storage access limited without permissions", Toast.LENGTH_SHORT).show()
            }
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            permissionLauncher.launch(
                arrayOf(
                    android.Manifest.permission.READ_MEDIA_IMAGES,
                    android.Manifest.permission.READ_MEDIA_VIDEO,
                    android.Manifest.permission.READ_MEDIA_AUDIO,
                    android.Manifest.permission.POST_NOTIFICATIONS
                )
            )
        } else {
            permissionLauncher.launch(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE))
        }

        setContent {
            var isDarkMode by remember { mutableStateOf(true) }
            val navController = rememberNavController()
            val storageBreakdown by remember { mutableStateOf(storageRepo.getStorageBreakdown()) }
            val healthInfo by remember { mutableStateOf(healthRepo.getDeviceHealthInfo()) }

            PhoneCareProTheme(darkTheme = isDarkMode) {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    NavHost(navController = navController, startDestination = "dashboard") {
                        composable("dashboard") {
                            DashboardScreen(
                                storageBreakdown = storageBreakdown,
                                healthInfo = healthInfo,
                                onNavigate = { navController.navigate(it) }
                            )
                        }
                        composable("smart_scan") {
                            SmartScanScreen(onBack = { navController.popBackStack() })
                        }
                        composable("advanced_photo_cleaner") {
                            AdvancedPhotoCleanerScreen(onBack = { navController.popBackStack() })
                        }
                        composable("video_cleaner") {
                            VideoCleanerScreen(onBack = { navController.popBackStack() })
                        }
                        composable("battery_monitor") {
                            BatteryMonitorScreen(onBack = { navController.popBackStack() })
                        }
                        composable("performance_assistant") {
                            PerformanceAssistantScreen(onBack = { navController.popBackStack() })
                        }
                        composable("security_centre") {
                            SecurityCentreScreen(onBack = { navController.popBackStack() })
                        }
                        composable("maintenance_history") {
                            MaintenanceHistoryScreen(
                                database = database,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}