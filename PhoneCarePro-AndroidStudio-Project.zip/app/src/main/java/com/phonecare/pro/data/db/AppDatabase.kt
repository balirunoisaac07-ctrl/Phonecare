package com.phonecare.pro.data.db

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "maintenance_history")
data class MaintenanceHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val actionType: String,
    val title: String,
    val filesRemovedCount: Int,
    val bytesRecovered: Long,
    val details: String
)

@Dao
interface MaintenanceHistoryDao {
    @Query("SELECT * FROM maintenance_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<MaintenanceHistoryEntity>>

    @Query("SELECT SUM(bytesRecovered) FROM maintenance_history")
    suspend fun getTotalBytesRecovered(): Long?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: MaintenanceHistoryEntity): Long

    @Query("DELETE FROM maintenance_history")
    suspend fun clearHistory()
}

@Database(entities = [MaintenanceHistoryEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun maintenanceHistoryDao(): MaintenanceHistoryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "phonecare_pro.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}